LVCOREF: Coreference resolution system for Latvian.
